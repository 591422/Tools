// ==UserScript==
// @name              百度网盘直链下载助手
// @namespace         https://github.com/syhyz1990/baiduyun
// @version           2.9.4
// @icon              https://www.baiduyun.wiki/48x48.png
// @description       【百度网盘直链下载助手】是一款免客户端获取百度网盘文件真实下载地址的油猴脚本，支持Windows，Mac，Linux，Android等多平台，可使用IDM，XDown等多线程加速工具加速下载，告别下载限速问题。
// @author            syhyz1990
// @license           MIT
// @supportURL        https://github.com/syhyz1990/baiduyun
// @updateURL         https://www.baiduyun.wiki/baiduyun.user.js
// @match             *://pan.baidu.com/disk/home*
// @match             *://yun.baidu.com/disk/home*
// @match             *://pan.baidu.com/s/*
// @match             *://yun.baidu.com/s/*
// @match             *://pan.baidu.com/share/*
// @match             *://yun.baidu.com/share/*
// @require           https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @require           https://cdn.bootcss.com/sweetalert/2.1.2/sweetalert.min.js
// @connect           baidu.com
// @connect           meek.com.cn
// @run-at            document-idle
// @grant             unsafeWindow
// @grant             GM_xmlhttpRequest
// @grant             GM_setClipboard
// @grant             GM_setValue
// @grant             GM_getValue
// @grant             GM_deleteValue
// @grant             GM_openInTab
// @grant             GM_registerMenuCommand
// @grant             GM_unregisterMenuCommand
// ==/UserScript==

"use strict";
!function () {
    function e(e, i, t) {
        e = e || "", i = i || "", t = t || "", console.group("[百度网盘直链下载助手]"), console.log(e, i, t), console.groupEnd();
    }

    function i(e, i) {
        var t = localStorage.getItem("baiduyunPlugin_BDUSS") ? localStorage.getItem("baiduyunPlugin_BDUSS") : '{"baiduyunPlugin_BDUSS":""}',
            n = JSON.parse(t).BDUSS;
        return n ? 'aria2c "' + e + '" --out "' + i + '" --header "User-Agent: ' + w + '" --header "Cookie: BDUSS=' + n + '"' : (swal({
            title: "提示",
            text: "请先安装【百度网盘万能助手】",
            buttons: {confirm: {text: "安装", value: "confirm"}}
        }).then(function (e) {
            "confirm" === e && (location.href = "https://www.baiduyun.wiki/zh-cn/assistant.html");
        }), "请先安装百度网盘万能助手，安装后请重启浏览器！！！");
    }

    function t(e) {
        return e ? e.replace(/&/g, "&amp;") : "";
    }

    function n() {
        function i() {
            Y = j(), W = V(), Q = U(), Z = l(), se = F(), "all" == se && (le = O()), "category" == se && (re = D()), "search" == se && (pe = N()), a(), t(), n();
        }

        function t() {
            "all" == se ? ie = z() : "category" == se ? ie = P() : "search" == se && (ie = L());
        }

        function n() {
            te = [];
        }

        function a() {
            oe = d();
        }

        function d() {
            return $("." + h.list).is(":hidden") ? "grid" : "list";
        }

        function s() {
            c(), p(), g(), b(), x();
        }

        function c() {
            window.addEventListener("hashchange", function (e) {
                a(), "all" == F() ? se == F() ? le != O() && (le = O(), t(), n()) : (se = F(), le = O(), t(), n()) : "category" == F() ? se == F() ? re != D() && (se = F(), re = D(), t(), n()) : (se = F(), re = D(), t(), n()) : "search" == F() && (se == F() ? pe != N() && (se = F(), pe = N(), t(), n()) : (se = F(), pe = N(), t(), n()));
            });
        }

        function p() {
            $("a[data-type=list]").click(function () {
                oe = "list";
            }), $("a[data-type=grid]").click(function () {
                oe = "grid";
            });
        }

        function g() {
            var i = $("span." + h.checkbox);
            "grid" == oe && (i = $("." + h["chekbox-grid"])), i.each(function (i, t) {
                $(t).on("click", function (i) {
                    var t = $(this).parent(), n = void 0, a = void 0;
                    if ("list" == oe ? (n = $("div.file-name div.text a", t).attr("title"), a = t.hasClass(h["item-active"])) : "grid" == oe && (n = $("div.file-name a", $(this)).attr("title"), a = !$(this).hasClass(h["item-active"])), a) {
                        e("取消选中文件：" + n);
                        for (var o = 0; o < te.length; o++) te[o].filename == n && te.splice(o, 1);
                    } else e("选中文件:" + n), $.each(ie, function (e, i) {
                        if (i.server_filename == n) {
                            var t = {filename: i.server_filename, path: i.path, fs_id: i.fs_id, isdir: i.isdir};
                            te.push(t);
                        }
                    });
                });
            });
        }

        function m() {
            $("span." + h.checkbox).each(function (e, i) {
                $(i).unbind("click");
            });
        }

        function b() {
            $("div." + h["col-item"] + "." + h.check).each(function (i, t) {
                $(t).bind("click", function (i) {
                    $(this).parent().hasClass(h.checked) ? (e("取消全选"), te = []) : (e("全部选中"), te = [], $.each(ie, function (e, i) {
                        var t = {filename: i.server_filename, path: i.path, fs_id: i.fs_id, isdir: i.isdir};
                        te.push(t);
                    }));
                });
            });
        }

        function y() {
            $("div." + h["col-item"] + "." + h.check).each(function (e, i) {
                $(i).unbind("click");
            });
        }

        function x() {
            $("div." + h["list-view"] + " dd").each(function (i, t) {
                $(t).bind("click", function (i) {
                    var t = i.target.nodeName.toLowerCase();
                    if ("span" != t && "a" != t && "em" != t) if (e("shiftKey:" + i.shiftKey), i.shiftKey) {
                        te = [];
                        var n = $("div." + h["list-view"] + " dd." + h["item-active"]);
                        $.each(n, function (i, t) {
                            var n = $("div.file-name div.text a", $(t)).attr("title");
                            e("选中文件：" + n), $.each(ie, function (e, i) {
                                if (i.server_filename == n) {
                                    var t = {filename: i.server_filename, path: i.path, fs_id: i.fs_id, isdir: i.isdir};
                                    te.push(t);
                                }
                            });
                        });
                    } else {
                        te = [];
                        var a = $("div.file-name div.text a", $(this)).attr("title");
                        e("选中文件：" + a), $.each(ie, function (e, i) {
                            if (i.server_filename == a) {
                                var t = {filename: i.server_filename, path: i.path, fs_id: i.fs_id, isdir: i.isdir};
                                te.push(t);
                            }
                        });
                    }
                });
            });
        }

        function k() {
            $("div." + h["list-view"] + " dd").each(function (e, i) {
                $(i).unbind("click");
            });
        }

        function _() {
            var e = window.MutationObserver, i = {childList: !0};
            de = new e(function (e) {
                m(), y(), k(), g(), b(), x();
            });
            var t = document.querySelector("." + h["list-view"]), n = document.querySelector("." + h["grid-view"]);
            de.observe(t, i), de.observe(n, i);
        }

        function A() {
            $("div." + h["bar-search"]).css("width", "18%");
            var e = $('<span class="g-dropdown-button"></span>'),
                i = $('<a class="g-button g-button-blue" href="javascript:;"><span class="g-button-right"><em class="icon icon-speed" title="百度网盘下载助手"></em><span class="text" style="width: 60px;">下载助手</span></span></a>'),
                t = $('<span class="menu" style="width:114px"></span>'),
                n = $('<span class="g-button-menu" style="display:block"></span>'),
                a = $('<span class="g-dropdown-button g-dropdown-button-second" menulevel="2"></span>'),
                o = $('<a class="g-button" href="javascript:;"><span class="g-button-right"><span class="text" style="width:auto">直链下载</span></span></a>'),
                d = $('<span class="menu" style="width:120px;left:79px"></span>'),
                s = $('<a id="batchhttplink-direct" class="g-button-menu" href="javascript:;">显示链接</a>');
            d.append(s), n.append(a.append(o).append(d)), n.hover(function () {
                a.toggleClass("button-open");
            }), s.click(E);
            var l = $('<span class="g-button-menu" style="display:block"></span>'),
                r = $('<span class="g-dropdown-button g-dropdown-button-second" menulevel="2"></span>'),
                c = $('<a class="g-button" href="javascript:;"><span class="g-button-right"><span class="text" style="width:auto">aria直链下载</span></span></a>'),
                p = $('<span class="menu" style="width:120px;left:79px"></span>'),
                u = $('<a id="batchhttplink-aria" class="g-button-menu" href="javascript:;">显示链接</a>');
            p.append(u), l.append(r.append(c).append(p)), l.hover(function () {
                r.toggleClass("button-open");
            }), u.click(E);
            var f = $('<span class="g-button-menu" style="display:block"></span>'),
                v = $('<span class="g-dropdown-button g-dropdown-button-second" menulevel="2"></span>'),
                g = $('<a class="g-button" href="javascript:;"><span class="g-button-right"><span class="text" style="width:auto">API下载</span></span></a>'),
                w = $('<span class="menu" style="width:120px;left:77px"></span>'),
                m = $('<a id="download-api" class="g-button-menu" href="javascript:;">直接下载</a>'),
                b = $('<a id="batchhttplink-api" class="g-button-menu" href="javascript:;">显示链接</a>'),
                y = $('<a id="appid-setting" class="g-button-menu" href="javascript:;">脚本配置</a>');
            w.append(m).append(b).append(y), f.append(v.append(g).append(w)), f.hover(function () {
                v.toggleClass("button-open");
            }), m.click(S), b.click(E), y.click(M);
            var x = $('<span class="g-button-menu" style="display:block"></span>'),
                k = $('<span class="g-dropdown-button g-dropdown-button-second" menulevel="2"></span>'),
                _ = $('<a class="g-button" href="javascript:;"><span class="g-button-right"><span class="text" style="width:auto">aria外链下载</span></span></a>'),
                A = $('<span class="menu" style="width:120px;left:79px"></span>'),
                C = $('<a id="batchlink-outerlink" class="g-button-menu" href="javascript:;">显示链接</a>');
            A.append(C), x.append(k.append(_).append(A)), x.hover(function () {
                k.toggleClass("button-open");
            }), C.click(E), t.append(f).append(l), e.append(i).append(t), e.hover(function () {
                e.toggleClass("button-open");
            }), $("." + h["list-tools"]).append(e), $("." + h["list-tools"]).css("height", "40px");
        }

        function M() {
            var e = prompt("请输入神秘代码 , 不懂请勿输入 , 否则后果自负", v);
            /^\d{1,6}$/.test(e) && (GM_setValue("secretCode", e), swal("神秘代码执行成功 , 点击确定将自动刷新"), history.go(0));
        }

        function S(i) {
            e("选中文件列表：", te);
            var t = i.target.id, n = void 0;
            if ("download-direct" == t) {
                var a = void 0;
                if (0 === te.length) return void swal(f.unselected);
                1 == te.length && (a = 1 === te[0].isdir ? "batch" : "dlink"), te.length > 1 && (a = "batch"), ee = R(te);
                var o = B(a);
                if (0 !== o.errno) return -1 == o.errno ? void swal("文件不存在或已被百度和谐，无法下载！") : 112 == o.errno ? void swal("页面过期，请刷新重试！") : void swal("发生错误！");
                if ("dlink" == a) n = o.dlink[0].dlink; else {
                    if ("batch" != a) return void swal("发生错误！");
                    n = o.dlink, 1 === te.length && (n = n + "&zipname=" + encodeURIComponent(te[0].filename) + ".zip");
                }
            } else {
                if (0 === te.length) return void swal(f.unselected);
                if (te.length > 1) return void swal(f.morethan);
                if (1 == te[0].isdir) return void swal(f.dir);
                "download-api" == t && (n = K(te[0].path));
            }
            J(n);
        }

        function E(i) {
            if (e("选中文件列表：", te), 0 === te.length) return void swal(f.unselected);
            var t = i.target.id, n = void 0, a = void 0;
            if (n = -1 == t.indexOf("https") ? -1 == t.indexOf("http") ? location.protocol + ":" : "http:" : "https:", ne = [], ae = [], -1 != t.indexOf("direct")) {
                ne = C(n);
                if (0 === ne.length) return void swal("没有链接可以显示，不要选中文件夹！");
                ce.open({
                    title: "直链下载",
                    type: "batch",
                    list: ne,
                    tip: '支持使用IDM批量下载，需升级 <a href="https://www.baiduyun.wiki/zh-cn/assistant.html">[百度网盘万能助手]</a> 至v2.0.3',
                    showcopy: !0
                });
            }
            if (-1 != t.indexOf("aria")) {
                if (ne = G(n), a = '请先安装 <a  href="https://www.baiduyun.wiki/zh-cn/assistant.html">百度网盘万能助手</a> 请将链接复制到支持Aria的下载器中, 推荐使用 <a  href="http://pan.baiduyun.wiki/down">XDown</a>（仅支持300M以下的文件夹）', 0 === ne.length) return void swal("没有链接可以显示，不要选中文件夹！");
                ce.open({title: "Aria链接", type: "batchAria", list: ne, tip: a, showcopy: !0});
            } else if (-1 != t.indexOf("api")) {
                if (ne = G(n), a = '请先安装 <a href="https://www.baiduyun.wiki/zh-cn/assistant.html">百度网盘万能助手</a> 右键"IDM下载"', 0 === ne.length) return void swal("没有链接可以显示，API链接不要全部选中文件夹！");
                ce.open({title: "API下载链接", type: "batch", list: ne, tip: a});
            } else -1 != t.indexOf("outerlink") && I(function (e) {
                if (ne = T(e), 0 === ne.length) return void swal("没有链接可以显示，API链接不要全部选中文件夹！");
                ce.open({
                    title: "下载链接（仅显示文件链接）",
                    type: "batchAria",
                    list: ne,
                    alllist: e,
                    tip: '请先安装 <a  href="https://www.baiduyun.wiki/zh-cn/assistant.html">百度网盘万能助手</a> 请将链接复制到支持Aria的下载器中, 推荐使用 <a  href="http://pan.baiduyun.wiki/down">XDown</a>',
                    showcopy: !0,
                    showall: !0
                });
            });
        }

        function C(e) {
            var i = [];
            return $.each(te, function (t, n) {
                var a = void 0, o = void 0, d = void 0;
                a = 0 == n.isdir ? "dlink" : "batch", ee = R([n]), d = B(a), 0 == d.errno ? ("dlink" == a ? o = d.dlink[0].dlink : "batch" == a && (o = d.dlink), o = o.replace(/^([A-Za-z]+):/, e)) : o = "error", i.push({
                    filename: n.filename,
                    downloadlink: o
                });
            }), i;
        }

        function G(e) {
            var i = [];
            return $.each(te, function (t, n) {
                if (1 != n.isdir) {
                    var a = void 0;
                    a = K(n.path), a = a.replace(/^([A-Za-z]+):/, e), i.push({filename: n.filename, downloadlink: a});
                }
            }), i;
        }

        function I(e) {
            $.each(te, function (i, t) {
                1 != t.isdir && H(t.path, function (i) {
                    var n = [];
                    0 == i.errno ? n.push({filename: t.filename, links: i.urls}) : n.push({
                        filename: t.filename,
                        links: [{rank: 1, url: "error"}]
                    }), e(n);
                });
            });
        }

        function T(e) {
            var i = [];
            return $.each(e, function (e, t) {
                i.push({filename: t.filename, downloadlink: t.links[0].url});
            }), i;
        }

        function j() {
            var e = void 0;
            try {
                e = new Function("return " + X.sign2)();
            } catch (e) {
                throw new Error(e.message);
            }
            return o(e(X.sign5, X.sign1));
        }

        function O() {
            var e = location.hash, i = new RegExp("path=([^&]*)(&|$)", "i"), t = e.match(i);
            return decodeURIComponent(t[1]);
        }

        function D() {
            var e = location.hash, i = new RegExp("type=([^&]*)(&|$)", "i"), t = e.match(i);
            return decodeURIComponent(t[1]);
        }

        function N() {
            var e = location.hash, i = new RegExp("key=([^&]*)(&|$)", "i"), t = e.match(i);
            return decodeURIComponent(t[1]);
        }

        function F() {
            var e = location.hash;
            return e.substring(e.indexOf("#") + 2, e.indexOf("?"));
        }

        function z() {
            var e = [], i = ue + "list", t = O();
            Z = l();
            var n = {
                dir: t,
                bdstoken: Q,
                logid: Z,
                order: "size",
                num: 1e3,
                desc: 0,
                clienttype: 0,
                showempty: 0,
                web: 1,
                channel: "chunlei",
                appid: v
            };
            return $.ajax({
                url: i, async: !1, method: "GET", data: n, success: function (i) {
                    e = 0 === i.errno ? i.list : [];
                }
            }), e;
        }

        function P() {
            var e = [], i = ue + "categorylist", t = D();
            Z = l();
            var n = {
                category: t,
                bdstoken: Q,
                logid: Z,
                order: "size",
                desc: 0,
                clienttype: 0,
                showempty: 0,
                web: 1,
                channel: "chunlei",
                appid: v
            };
            return $.ajax({
                url: i, async: !1, method: "GET", data: n, success: function (i) {
                    e = 0 === i.errno ? i.info : [];
                }
            }), e;
        }

        function L() {
            var e = [], i = ue + "search";
            Z = l(), pe = N();
            var t = {
                recursion: 1,
                order: "time",
                desc: 1,
                showempty: 0,
                web: 1,
                page: 1,
                num: 100,
                key: pe,
                channel: "chunlei",
                app_id: 250528,
                bdstoken: Q,
                logid: Z,
                clienttype: 0
            };
            return $.ajax({
                url: i, async: !1, method: "GET", data: t, success: function (i) {
                    e = 0 === i.errno ? i.list : [];
                }
            }), e;
        }

        function R(e) {
            if (0 === e.length) return null;
            var i = [];
            return $.each(e, function (e, t) {
                i.push(t.fs_id);
            }), "[" + i + "]";
        }

        function V() {
            return X.timestamp;
        }

        function U() {
            return X.MYBDSTOKEN;
        }

        function B(e) {
            var i = void 0;
            Z = l();
            var t = {bdstoken: Q, logid: Z}, n = {sign: Y, timestamp: W, fidlist: ee, type: e},
                a = "https://pan.baidu.com/api/download?bdstoken=" + t.bdstoken + "&web=5&app_id=250528&logid=" + t.logid + "=&channel=chunlei&clienttype=5";
            return $.ajax({
                url: a, async: !1, method: "POST", data: n, success: function (e) {
                    i = e;
                }
            }), i;
        }

        function K(e) {
            return he + "file?method=download&path=" + encodeURIComponent(e) + "&app_id=" + v;
        }

        function H(e, i) {
            var t = void 0,
                n = fe + "file?method=locatedownload&app_id=" + v + "&ver=4.0&path=" + encodeURIComponent(e);
            GM_xmlhttpRequest({
                method: "POST", url: n, headers: {"User-Agent": w}, onload: function (e) {
                    200 === e.status ? (t = JSON.parse(e.responseText), void 0 == t.error_code ? void 0 == t.urls ? t.errno = 2 : ($.each(t.urls, function (e, i) {
                        t.urls[e].url = i.url.replace("\\", "");
                    }), t.errno = 0) : 31066 == t.error_code ? t.errno = 1 : t.errno = -1) : (t = {}, t.errno = -1), i(t);
                }
            });
        }

        function J(i) {
            e("下载链接：" + i), $("#helperdownloadiframe").attr("src", i);
        }

        function q() {
            var e = $('<div class="helper-hide" style="padding:0;margin:0;display:block"></div>'),
                i = $('<iframe src="javascript:;" id="helperdownloadiframe" style="display:none"></iframe>');
            e.append(i), $("body").append(e);
        }

        var X = void 0, Y = void 0, W = void 0, Q = void 0, Z = void 0, ee = void 0, ie = [], te = [], ne = [], ae = [],
            oe = "list", de = void 0, se = void 0, le = void 0, re = void 0, ce = void 0, pe = void 0,
            ue = location.protocol + "//" + location.host + "/api/",
            he = location.protocol + "//pcs.baidu.com/rest/2.0/pcs/",
            fe = location.protocol + "//d.pcs.baidu.com/rest/2.0/pcs/";
        this.init = function () {
            if (X = unsafeWindow.yunData, e("初始化信息:", X), void 0 === X) return void e("页面未正常加载，或者百度已经更新！");
            i(), s(), _(), A(), q(), ce = new r({addCopy: !0}), e("下载助手加载成功！当前版本：", u);
        };
    }

    function a() {
        function i() {
            if (re = t(), J = H.SIGN, q = H.TIMESTAMP, X = H.MYBDSTOKEN, Y = "chunlei", W = 0, Q = 1, Z = v, ee = l(), ie = 0, te = "share", ae = H.SHARE_ID, ne = H.SHARE_UK, "secret" == re && (de = o()), n()) {
                var e = {};
                2 == H.CATEGORY ? (e.filename = H.FILENAME, e.path = H.PATH, e.fs_id = H.FS_ID, e.isdir = 0) : void 0 != H.FILEINFO && (e.filename = H.FILEINFO[0].server_filename, e.path = H.FILEINFO[0].path, e.fs_id = H.FILEINFO[0].fs_id, e.isdir = H.FILEINFO[0].isdir), we.push(e);
            } else se = H.SHARE_ID, pe = d(), ue = p(), ge = N();
        }

        function t() {
            return 1 === H.SHARE_PUBLIC ? "public" : "secret";
        }

        function n() {
            return void 0 === H.getContext;
        }

        function a() {
            return 1 == H.MYSELF;
        }

        function o() {
            return '{"sekey":"' + decodeURIComponent(s("BDCLND")) + '"}';
        }

        function d() {
            var e = location.hash, i = new RegExp("path=([^&]*)(&|$)", "i"), t = e.match(i);
            return decodeURIComponent(t[1]);
        }

        function p() {
            var e = "list";
            return $(".list-switched-on").length > 0 ? e = "list" : $(".grid-switched-on").length > 0 && (e = "grid"), e;
        }

        function w() {
            n() ? ($("div.slide-show-right").css("width", "500px"), $("div.frame-main").css("width", "96%"), $("div.share-file-viewer").css("width", "740px").css("margin-left", "auto").css("margin-right", "auto")) : $("div.slide-show-right").css("width", "500px");
            var e = $('<span class="g-dropdown-button"></span>'),
                i = $('<a class="g-button g-button-blue" style="width: 114px;" data-button-id="b200" data-button-index="200" href="javascript:;"></a>'),
                t = $('<span class="g-button-right"><em class="icon icon-speed" title="百度网盘下载助手"></em><span class="text" style="width: 60px;">下载助手</span></span>'),
                a = $('<span class="menu" style="width:auto;z-index:41"></span>'),
                o = $('<a data-menu-id="b-menu207" class="g-button-menu" href="javascript:;">一键保存</a>'),
                d = $('<a data-menu-id="b-menu207" class="g-button-menu" href="javascript:;" style="opacity: 0.8;">自定义保存路径</a>'),
                s = $('<a data-menu-id="b-menu207" class="g-button-menu" href="javascript:;">直接下载</a>'),
                l = $('<a data-menu-id="b-menu208" class="g-button-menu" href="javascript:;">显示直链</a>'),
                r = $('<a data-menu-id="b-menu208" class="g-button-menu" href="javascript:;">显示aria链接</a>'),
                c = $('<iframe src="https://ghbtns.com/github-btn.html?user=syhyz1990&repo=baiduyun&type=star&count=true" frameborder="0" scrolling="0" style="height: 20px;max-width: 120px;padding: 0 5px;box-sizing: border-box;margin-top: 5px;"></iframe>');
            a.append(l).append(r).append(o).append(c), i.append(t), e.append(i).append(a), e.hover(function () {
                e.toggleClass("button-open");
            }), o.click(b), d.click(y), s.click(F), l.click(V), r.click(x), $("div.module-share-top-bar div.bar div.x-button-box").append(e);
        }

        function m() {
            var e = {shareid: se, from: H.SHARE_UK, bdstoken: H.MYBDSTOKEN, logid: l()},
                i = {path: g, isdir: 1, size: "", block_list: [], method: "post", dataType: "json"},
                t = "https://pan.baidu.com/api/create?a=commit&channel=chunlei&app_id=250528&web=1&app_id=250528&bdstoken=" + e.bdstoken + "&logid=" + e.logid + "&clienttype=0";
            $.ajax({
                url: t, async: !1, method: "POST", data: i, success: function (e) {
                    0 === e.errno ? (swal("目录创建成功！"), b()) : swal("目录创建失败，请前往我的网盘页面手动创建！");
                }
            });
        }

        function b() {
            if (null === X) return swal(f.unlogin), !1;
            if (0 === we.length) return void swal(f.unselected);
            if (a()) return void swal({
                title: "提示",
                text: "自己分享的文件请到网盘中下载！",
                buttons: {confirm: {text: "打开网盘", value: "confirm"}}
            }).then(function (e) {
                "confirm" === e && (location.href = "https://pan.baidu.com/disk/home#/all?path=%2F&vmode=list");
            });
            var e = [];
            $.each(we, function (i, t) {
                e.push(t.fs_id);
            });
            var i = {shareid: H.SHARE_ID, from: H.SHARE_UK, bdstoken: H.MYBDSTOKEN, logid: l()},
                t = {path: GM_getValue("savePath"), fsidlist: JSON.stringify(e)},
                n = "https://pan.baidu.com/share/transfer?shareid=" + i.shareid + "&from=" + i.from + "&ondup=newcopy&async=1&channel=chunlei&web=1&app_id=250528&bdstoken=" + i.bdstoken + "&logid=" + i.logid + "&clienttype=0";
            $.ajax({
                url: n, async: !1, method: "POST", data: t, success: function (e) {
                    0 === e.errno ? swal({
                        title: "提示",
                        text: "文件已保存至我的网盘，请再网盘中使用下载助手下载！",
                        buttons: {confirm: {text: "打开网盘", value: "confirm"}}
                    }).then(function (e) {
                        "confirm" === e && (location.href = "https://pan.baidu.com/disk/home#/all?vmode=list&path=" + encodeURIComponent(g));
                    }) : 2 === e.errno ? swal({
                        title: "提示",
                        text: "保存目录不存在，是否先创建该目录？",
                        buttons: {confirm: {text: "创建目录", value: "confirm"}}
                    }).then(function (e) {
                        "confirm" === e && m();
                    }) : swal("保存失败，请手动保存");
                }
            });
        }

        function y() {
            var e = prompt("请输入保存路径，例如/PanHelper", g);
            null !== e && (/^\//.test(e) ? (GM_setValue("savePath", e), swal({
                title: "提示",
                text: "路径设置成功！点击确定后立即生效",
                buttons: {confirm: {text: "确定", value: "confirm"}}
            }).then(function (e) {
                "confirm" === e && history.go(0);
            })) : swal("请输入正确的路径，例如/PanHelper"));
        }

        function x() {
            return null === X ? (swal(f.unlogin), !1) : (e("选中文件列表：", we), 0 === we.length ? (swal(f.unselected), !1) : 1 == we[0].isdir ? (swal(f.toobig), !1) : (ce = "ariclink", void U(function (e) {
                if (void 0 !== e) if (-20 == e.errno) {
                    if (!(le = z()) || 0 !== le.errno) return swal("获取验证码失败！"), !1;
                    ve.open(le);
                } else {
                    if (112 == e.errno) return swal("页面过期，请刷新重试"), !1;
                    if (0 === e.errno) {
                        fe.open({
                            title: "下载链接（仅显示文件链接）",
                            type: "shareAriaLink",
                            list: e.list,
                            tip: '请先安装 <a  href="https://www.baiduyun.wiki/zh-cn/assistant.html">百度网盘万能助手</a> 请将链接复制到支持Aria的下载器中, 推荐使用 <a  href="http://pan.baiduyun.wiki/down">XDown</a>',
                            showcopy: !0
                        });
                    } else swal(f.fail);
                }
            })));
        }

        function k() {
            var e = $('<div class="helper-hide" style="padding:0;margin:0;display:block"></div>'),
                i = $('<iframe src="javascript:;" id="helperdownloadiframe" style="display:none"></iframe>');
            e.append(i), $("body").append(e);
        }

        function _() {
            A(), E(), C(), I(), j();
        }

        function A() {
            window.addEventListener("hashchange", function (e) {
                ue = p(), pe == d() || (pe = d(), M(), S());
            });
        }

        function M() {
            ge = N();
        }

        function S() {
            we = [];
        }

        function E() {
            p();
        }

        function C() {
            ue = p();
            var i = $("span." + h.checkbox);
            "grid" == ue && (i = $("." + h["chekbox-grid"])), i.each(function (i, t) {
                $(t).on("click", function (i) {
                    var t = $(this).parent(), n = void 0, a = void 0;
                    if ("list" == ue ? (n = $(".file-name div.text a", t).attr("title"), a = $(this).parents("dd").hasClass("JS-item-active")) : "grid" == ue && (n = $("div.file-name a", t).attr("title"), a = !$(this).hasClass("JS-item-active")), a) {
                        e("取消选中文件：" + n);
                        for (var o = 0; o < we.length; o++) we[o].filename == n && we.splice(o, 1);
                    } else e("选中文件: " + n), $.each(ge, function (e, i) {
                        if (i.server_filename == n) {
                            var t = {filename: i.server_filename, path: i.path, fs_id: i.fs_id, isdir: i.isdir};
                            we.push(t);
                        }
                    });
                });
            });
        }

        function G() {
            $("span." + h.checkbox).each(function (e, i) {
                $(i).unbind("click");
            });
        }

        function I() {
            $("div." + h["col-item"] + "." + h.check).each(function (i, t) {
                $(t).bind("click", function (i) {
                    $(this).parent().hasClass(h.checked) ? (e("取消全选"), we = []) : (e("全部选中"), we = [], $.each(ge, function (e, i) {
                        var t = {filename: i.server_filename, path: i.path, fs_id: i.fs_id, isdir: i.isdir};
                        we.push(t);
                    }));
                });
            });
        }

        function T() {
            $("div." + h["col-item"] + "." + h.check).each(function (e, i) {
                $(i).unbind("click");
            });
        }

        function j() {
            $("div." + h["list-view"] + " dd").each(function (i, t) {
                $(t).bind("click", function (i) {
                    var t = i.target.nodeName.toLowerCase();
                    if ("span" != t && "a" != t && "em" != t) {
                        we = [];
                        var n = $("div.file-name div.text a", $(this)).attr("title");
                        e("选中文件：" + n), $.each(ge, function (e, i) {
                            if (i.server_filename == n) {
                                var t = {filename: i.server_filename, path: i.path, fs_id: i.fs_id, isdir: i.isdir};
                                we.push(t);
                            }
                        });
                    }
                });
            });
        }

        function O() {
            $("div." + h["list-view"] + " dd").each(function (e, i) {
                $(i).unbind("click");
            });
        }

        function D() {
            var e = window.MutationObserver, i = {childList: !0};
            he = new e(function (e) {
                G(), T(), O(), C(), I(), j();
            });
            var t = document.querySelector("." + h["list-view"]), n = document.querySelector("." + h["grid-view"]);
            he.observe(t, i), he.observe(n, i);
        }

        function N() {
            var e = [];
            if ("/" == d()) e = H.FILEINFO; else {
                ee = l();
                var i = {
                    uk: ne,
                    shareid: se,
                    order: "other",
                    desc: 1,
                    showempty: 0,
                    web: Q,
                    dir: d(),
                    t: Math.random(),
                    bdstoken: X,
                    channel: Y,
                    clienttype: W,
                    app_id: Z,
                    logid: ee
                };
                $.ajax({
                    url: be, method: "GET", async: !1, data: i, success: function (i) {
                        0 === i.errno && (e = i.list);
                    }
                });
            }
            return e;
        }

        function F() {
            return null === X ? (swal(f.unlogin), !1) : (e("选中文件列表：", we), 0 === we.length ? (swal(f.unselected), !1) : we.length > 1 ? (swal(f.morethan), !1) : 1 == we[0].isdir ? (swal(f.dir), !1) : (ce = "download", void U(function (e) {
                if (void 0 !== e) if (-20 == e.errno) {
                    if (le = z(), 0 !== le.errno) return void swal("获取验证码失败！");
                    ve.open(le);
                } else if (112 == e.errno) swal("页面过期，请刷新重试"); else if (0 === e.errno) {
                    var i = e.list[0].dlink;
                    K(i);
                } else swal(f.fail);
            })));
        }

        function z() {
            var e = me + "getvcode", i = void 0;
            ee = l();
            var t = {
                prod: "pan",
                t: Math.random(),
                bdstoken: X,
                channel: Y,
                clienttype: W,
                web: Q,
                app_id: Z,
                logid: ee
            };
            return $.ajax({
                url: e, method: "GET", async: !1, data: t, success: function (e) {
                    i = e;
                }
            }), i;
        }

        function P() {
            le = z(), $("#dialog-img").attr("src", le.img);
        }

        function L() {
            var e = $("#dialog-input").val();
            return 0 === e.length ? void $("#dialog-err").text("请输入验证码") : e.length < 4 ? void $("#dialog-err").text("验证码输入错误，请重新输入") : void B(e, function (e) {
                if (-20 == e.errno) {
                    if (ve.close(), $("#dialog-err").text("验证码输入错误，请重新输入"), P(), !le || 0 !== le.errno) return void swal("获取验证码失败！");
                    ve.open();
                } else if (0 === e.errno) {
                    if (ve.close(), "download" == ce) {
                        if (e.list.length > 1 || 1 == e.list[0].isdir) return swal(f.morethan), !1;
                        var i = e.list[0].dlink;
                        K(i);
                    } else if ("link" == ce) {
                        fe.open({
                            title: "下载链接（仅显示文件链接）",
                            type: "shareLink",
                            list: e.list,
                            tip: '支持使用IDM批量下载，需升级 <a href="https://www.baiduyun.wiki/zh-cn/assistant.html">[百度网盘万能助手]</a> 至v2.0.3',
                            showcopy: !0
                        });
                    } else if ("ariclink" == ce) {
                        fe.open({
                            title: "下载链接（仅显示文件链接）",
                            type: "shareAriaLink",
                            list: e.list,
                            tip: '请先安装 <a  href="https://www.baiduyun.wiki/zh-cn/assistant.html">百度网盘万能助手</a> 请将链接复制到支持Aria的下载器中, 推荐使用 <a  href="http://pan.baiduyun.wiki/down">XDown</a>',
                            showcopy: !0
                        });
                    }
                } else swal("发生错误！");
            });
        }

        function R() {
            var e = [];
            return $.each(we, function (i, t) {
                e.push(t.fs_id);
            }), "[" + e + "]";
        }

        function V() {
            return null === X ? (swal(f.unlogin), !1) : (e("选中文件列表：", we), 0 === we.length ? (swal(f.unselected), !1) : 1 == we[0].isdir ? (swal(f.dir), !1) : (ce = "link", void U(function (e) {
                if (void 0 !== e) if (-20 == e.errno) {
                    if (!(le = z()) || 0 !== le.errno) return swal("获取验证码失败！"), !1;
                    ve.open(le);
                } else {
                    if (112 == e.errno) return swal("页面过期，请刷新重试"), !1;
                    if (0 === e.errno) {
                        fe.open({
                            title: "下载链接（仅显示文件链接）",
                            type: "shareLink",
                            list: e.list,
                            tip: '支持使用IDM批量下载，需升级 <a href="https://www.baiduyun.wiki/zh-cn/assistant.html">[百度网盘万能助手]</a> 至v2.0.3',
                            showcopy: !0
                        });
                    } else swal(f.fail);
                }
            })));
        }

        function U(e) {
            if (null === X) return swal(f.unlogin), "";
            var i = void 0;
            if (n) {
                oe = R(), ee = l();
                var t = new FormData;
                t.append("encrypt", ie), t.append("product", te), t.append("uk", ne), t.append("primaryid", ae), t.append("fid_list", oe), "secret" == re && t.append("extra", de), $.ajax({
                    url: "https://api.baiduyun.wiki/download?sign=" + J + "&timestamp=" + q + "&logid=" + ee + "&init=" + GM_getValue("init"),
                    cache: !1,
                    method: "GET",
                    async: !1,
                    complete: function (e) {
                        i = e.responseText;
                    }
                }), GM_xmlhttpRequest({
                    method: "POST", data: t, url: atob(atob(i)), onload: function (i) {
                        e(JSON.parse(i.response));
                    }
                });
            }
        }

        function B(e, i) {
            var t = void 0;
            if (n) {
                oe = R(), ee = l();
                var a = new FormData;
                a.append("encrypt", ie), a.append("product", te), a.append("uk", ne), a.append("primaryid", ae), a.append("fid_list", oe), a.append("vcode_input", e), a.append("vcode_str", le.vcode), "secret" == re && a.append("extra", de), $.ajax({
                    url: "https://api.baiduyun.wiki/download?sign=" + J + "&timestamp=" + q + "&logid=" + ee,
                    cache: !1,
                    method: "GET",
                    async: !1,
                    complete: function (e) {
                        t = e.responseText;
                    }
                }), GM_xmlhttpRequest({
                    method: "POST", data: a, url: atob(atob(t)), onload: function (e) {
                        i(JSON.parse(e.response));
                    }
                });
            }
        }

        function K(i) {
            e("下载链接：" + i), $("#helperdownloadiframe").attr("src", i);
        }

        var H = void 0, J = void 0, q = void 0, X = void 0, Y = void 0, W = void 0, Q = void 0, Z = void 0, ee = void 0,
            ie = void 0, te = void 0, ne = void 0, ae = void 0, oe = void 0, de = void 0, se = void 0, le = void 0,
            re = void 0, ce = void 0, pe = void 0, ue = void 0, he = void 0, fe = void 0, ve = void 0, ge = [], we = [],
            me = location.protocol + "//" + location.host + "/api/",
            be = location.protocol + "//" + location.host + "/share/list";
        this.init = function () {
            if (H = unsafeWindow.yunData, e("初始化信息:", H), void 0 === H) return void e("页面未正常加载，或者百度已经更新！");
            i(), w(), fe = new r({addCopy: !1}), ve = new c(P, L), k(), n() || (_(), D()), e("下载助手加载成功！当前版本：", u);
        };
    }

    function o(e) {
        var i = void 0, t = void 0, n = void 0, a = void 0, o = void 0, d = void 0,
            s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        for (n = e.length, t = 0, i = ""; n > t;) {
            if (a = 255 & e.charCodeAt(t++), t == n) {
                i += s.charAt(a >> 2), i += s.charAt((3 & a) << 4), i += "==";
                break;
            }
            if (o = e.charCodeAt(t++), t == n) {
                i += s.charAt(a >> 2), i += s.charAt((3 & a) << 4 | (240 & o) >> 4), i += s.charAt((15 & o) << 2), i += "=";
                break;
            }
            d = e.charCodeAt(t++), i += s.charAt(a >> 2), i += s.charAt((3 & a) << 4 | (240 & o) >> 4), i += s.charAt((15 & o) << 2 | (192 & d) >> 6), i += s.charAt(63 & d);
        }
        return i;
    }

    function d() {
        var e = /[\/].+[\/]/g;
        return location.pathname.match(e)[0].replace(/\//g, "");
    }

    function s(e) {
        var i = void 0, t = void 0, n = document, a = decodeURI;
        return n.cookie.length > 0 && -1 != (i = n.cookie.indexOf(e + "=")) ? (i = i + e.length + 1, t = n.cookie.indexOf(";", i), -1 == t && (t = n.cookie.length), a(n.cookie.substring(i, t))) : "";
    }

    function l() {
        function e(e) {
            if (e.length < 2) {
                var i = e.charCodeAt(0);
                return 128 > i ? e : 2048 > i ? l(192 | i >>> 6) + l(128 | 63 & i) : l(224 | i >>> 12 & 15) + l(128 | i >>> 6 & 63) + l(128 | 63 & i);
            }
            var t = 65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
            return l(240 | t >>> 18 & 7) + l(128 | t >>> 12 & 63) + l(128 | t >>> 6 & 63) + l(128 | 63 & t);
        }

        function i(i) {
            return (i + "" + Math.random()).replace(d, e);
        }

        function t(e) {
            var i = [0, 2, 1][e.length % 3],
                t = e.charCodeAt(0) << 16 | (e.length > 1 ? e.charCodeAt(1) : 0) << 8 | (e.length > 2 ? e.charCodeAt(2) : 0);
            return [o.charAt(t >>> 18), o.charAt(t >>> 12 & 63), i >= 2 ? "=" : o.charAt(t >>> 6 & 63), i >= 1 ? "=" : o.charAt(63 & t)].join("");
        }

        function n(e) {
            return e.replace(/[\s\S]{1,3}/g, t);
        }

        function a() {
            return n(i((new Date).getTime()));
        }

        var o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/~！@#￥%……&",
            d = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, l = String.fromCharCode;
        return function (e, i) {
            return i ? a(String(e)).replace(/[+\/]/g, function (e) {
                return "+" == e ? "-" : "_";
            }).replace(/=/g, "") : a(String(e));
        }(s("BAIDUID"));
    }

    function r() {
        function e() {
            $("div.dialog-body", o).children().remove(), $("div.dialog-header h3 span.dialog-title", o).text(""), $("div.dialog-tip p", o).text(""), $("div.dialog-button", o).hide(), $("div.dialog-radio input[type=radio][name=showmode][value=multi]", o).prop("checked", !0), $("div.dialog-radio", o).hide(), $("div.dialog-button button#dialog-copy-button", o).hide(), $("div.dialog-button button#dialog-edit-button", o).hide(), $("div.dialog-button button#dialog-exit-button", o).hide(), o.hide(), d.hide();
        }

        var n = [], a = void 0, o = void 0, d = void 0;
        this.open = function (e) {
            if (a = e, n = [], "link" == e.type && (n = e.list.urls, $("div.dialog-header h3 span.dialog-title", o).text(e.title + "：" + e.list.filename), $.each(e.list.urls, function (e, i) {
                i.url = t(i.url);
                var n = $('<div><div style="width:30px;float:left">' + i.rank + ':</div><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><a href="' + i.url + '">' + i.url + "</a></div></div>");
                $("div.dialog-body", o).append(n);
            })), "batch" != e.type && "batchAria" != e.type || (n = e.list, $("div.dialog-header h3 span.dialog-title", o).text(e.title), e.showall ? $.each(e.list, function (n, a) {
                var d = $('<div class="item-container" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></div>'),
                    s = $('<div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + a.filename + '">' + a.filename + "</div>"),
                    l = $('<div style="width:12px;float:left"><span>：</span></div>'),
                    r = $('<div class="item-link" style="float:left;width:618px;"></div>'), c = void 0;
                if ("batchAria" == e.type) {
                    var p = i(a.downloadlink, a.filename);
                    c = $('<div class="item-first" style="overflow:hidden;text-overflow:ellipsis"><a href="javasctipt:void(0)" class="aria2c-link">' + p + "</a></div>");
                } else c = $('<div class="item-first" style="overflow:hidden;text-overflow:ellipsis"><a href="' + a.downloadlink + '">' + a.downloadlink + "</a></div>");
                r.append(c), $.each(e.alllist[n].links, function (n, o) {
                    var d = void 0;
                    if (a.downloadlink != o.url) {
                        if ("batchAria" == e.type) {
                            var s = i(o.url, a.filename);
                            d = $('<div class="item-ex" style="display:none;overflow:hidden;text-overflow:ellipsis"><a href="javasctipt:void(0)" class="aria2c-link">' + s + "</a></div>");
                        } else o.url = t(o.url), d = $('<div class="item-ex" style="display:none;overflow:hidden;text-overflow:ellipsis"><a href="' + o.url + '">' + o.url + "</a></div>");
                        r.append(d);
                    }
                });
                var u = $('<div style="width:15px;float:left;cursor:pointer;text-align:center;font-size:16px"><span>+</span></div>');
                d.append(s).append(l).append(r).append(u), u.click(function () {
                    var e = $(this).parent();
                    e.toggleClass("showall"), e.hasClass("showall") ? ($(this).text("-"), $("div.item-link div.item-ex", e).show()) : ($(this).text("+"), $("div.item-link div.item-ex", e).hide());
                }), $("div.dialog-body", o).append(d);
            }) : $.each(e.list, function (t, n) {
                var a = void 0;
                if ("batchAria" == e.type) {
                    var d = i(n.downloadlink, n.filename);
                    a = $('<div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + n.filename + '">' + n.filename + '</div><span>：</span><a href="javascript:;" class="aria2c-link">' + d + "</a></div>");
                } else a = $('<div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + n.filename + '">' + n.filename + '</div><span>：</span><a href="' + n.downloadlink + '">' + n.downloadlink + "</a></div>");
                $("div.dialog-body", o).append(a);
            })), "shareLink" == e.type && (n = e.list, $("div.dialog-header h3 span.dialog-title", o).text(e.title), $.each(e.list, function (e, i) {
                if (i.dlink = t(i.dlink), 1 != i.isdir) {
                    var n = $('<div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + i.server_filename + '">' + i.server_filename + '</div><span>：</span><a href="' + i.dlink + '">' + i.dlink + "</a></div>");
                    $("div.dialog-body", o).append(n);
                }
            })), "shareAriaLink" == e.type && (n = e.list, $("div.dialog-header h3 span.dialog-title", o).text(e.title), $.each(e.list, function (e, t) {
                if (1 != t.isdir) {
                    var n = i(t.dlink, t.server_filename),
                        a = $('<div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + t.server_filename + '">' + t.server_filename + '</div><span>：</span><a href="javasctipt:void(0)" class="aria2c-link">' + n + "</a></div>");
                    $("div.dialog-body", o).append(a);
                }
            })), e.tip && $("div.dialog-tip p", o).html(e.tip), e.showcopy && ($("div.dialog-button", o).show(), $("div.dialog-button button#dialog-copy-button", o).show()), e.showedit) {
                $("div.dialog-button", o).show(), $("div.dialog-button button#dialog-edit-button", o).show();
                var s = $('<textarea name="dialog-textarea" style="display:none;resize:none;width:758px;height:300px;white-space:pre;word-wrap:normal;overflow-x:scroll"></textarea>'),
                    l = "";
                "batch" == a.type ? $.each(n, function (e, i) {
                    "error" != i.downloadlink && (e == n.length - 1 ? l += i.downloadlink : l += i.downloadlink + "\r\n");
                }) : "link" == a.type && $.each(n, function (e, i) {
                    "error" != i.url && (e == n.length - 1 ? l += i.url : l += i.url + "\r\n");
                }), s.val(l), $("div.dialog-body", o).append(s);
            }
            d.show(), o.show();
        }, this.close = function () {
            e();
        }, o = function () {
            var t = document.body.clientWidth, d = t > 800 ? (t - 800) / 2 : 0,
                s = $('<div class="dialog" style="width: 800px; top: 0px; bottom: auto; left: ' + d + 'px; right: auto; display: hidden; visibility: visible; z-index: 52;"></div>'),
                l = $('<div class="dialog-header"><h3><span class="dialog-title" style="display:inline-block;width:740px;white-space:nowrap;overflow-x:hidden;text-overflow:ellipsis"></span></h3></div>'),
                r = $('<div class="dialog-control"><span class="dialog-icon dialog-close">×</span></div>'),
                c = $('<div class="dialog-body" style="max-height:450px;overflow-y:auto;padding:0 20px;"></div>'),
                p = $('<div class="dialog-tip" style="padding-left:20px;background-color:#fff;border-top: 1px solid #c4dbfe;color: #dc373c;"><p></p></div>');
            s.append(l.append(r)).append(c)
            ;var u = $('<div class="dialog-button" style="display:none"></div>'),
                h = $('<div style="display:table;margin:auto"></div>'),
                f = $('<button id="dialog-copy-button" style="display:none;width: 100px; margin: 5px 0 10px 0; cursor: pointer; background: #cc3235; border: none; height: 30px; color: #fff; border-radius: 3px;">复制全部链接</button>'),
                v = $('<button id="dialog-edit-button" style="display:none">编辑</button>'),
                g = $('<button id="dialog-exit-button" style="display:none">退出</button>');
            return h.append(f).append(v).append(g), u.append(h), s.append(u), f.click(function () {
                var e = "";
                "batch" == a.type ? $.each(n, function (i, t) {
                    "error" != t.downloadlink && (i == n.length - 1 ? e += t.downloadlink : e += t.downloadlink + "\r\n");
                }) : "batchAria" == a.type ? $.each(n, function (t, a) {
                    "error" != a.downloadlink && (t == n.length - 1 ? e += i(a.downloadlink, a.filename) : e += i(a.downloadlink, a.filename) + "\r\n");
                }) : "shareLink" == a.type ? $.each(n, function (i, t) {
                    "error" != t.dlink && (i == n.length - 1 ? e += t.dlink : e += t.dlink + "\r\n");
                }) : "shareAriaLink" == a.type && $.each(n, function (t, a) {
                    "error" != a.dlink && (t == n.length - 1 ? e += i(a.dlink, a.server_filename) : e += i(a.dlink, a.server_filename) + "\r\n");
                }), GM_setClipboard(e, "text"), "" != e ? swal("已将链接复制到剪贴板！") : swal("复制失败，请手动复制！");
            }), v.click(function () {
                var e = $("div.dialog-body textarea[name=dialog-textarea]", o);
                $("div.dialog-body div", o).hide(), f.hide(), v.hide(), e.show(), $dialog_radio_div.show(), g.show();
            }), g.click(function () {
                var e = $("div.dialog-body textarea[name=dialog-textarea]", o), i = $("div.dialog-body div", o);
                e.hide(), $dialog_radio_div.hide(), i.show(), g.hide(), f.show(), v.show();
            }), s.append(p), $("body").append(s), r.click(e), s;
        }(), d = function () {
            var e = $('<div class="dialog-shadow" style="position: fixed; left: 0px; top: 0px; z-index: 50; background: rgb(0, 0, 0) none repeat scroll 0% 0%; opacity: 0.5; width: 100%; height: 100%; display: none;"></div>');
            return $("body").append(e), e;
        }();
    }

    function c(e, i) {
        function t() {
            $("#dialog-img", n).attr("src", ""), $("#dialog-err").text(""), n.hide(), a.hide();
        }

        var n = void 0, a = void 0;
        this.open = function (e) {
            e && $("#dialog-img").attr("src", e.img), n.show(), a.show();
        }, this.close = function () {
            t();
        }, n = function () {
            var n = document.body.clientWidth, a = n > 520 ? (n - 520) / 2 : 0,
                o = $('<div class="dialog" id="dialog-vcode" style="width:520px;top:0px;bottom:auto;left:' + a + 'px;right:auto;display:none;visibility:visible;z-index:52"></div>'),
                d = $('<div class="dialog-header"><h3><span class="dialog-header-title"><em class="select-text">提示</em></span></h3></div>'),
                s = $('<div class="dialog-control"><span class="dialog-icon dialog-close icon icon-close"><span class="sicon">x</span></span></div>'),
                l = $('<div class="dialog-body"></div>'), r = $('<div style="text-align:center;padding:22px"></div>'),
                c = $('<div class="download-verify" style="margin-top:10px;padding:0 28px;text-align:left;font-size:12px;"></div>'),
                p = $('<div class="verify-body">请输入验证码：</div>'),
                u = $('<input id="dialog-input" type="text" style="padding:3px;width:85px;height:23px;border:1px solid #c6c6c6;background-color:white;vertical-align:middle;" class="input-code" maxlength="4">'),
                h = $('<img id="dialog-img" class="img-code" style="margin-left:10px;vertical-align:middle;" alt="点击换一张" src="" width="100" height="30">'),
                f = $('<a href="javascript:;" style="text-decoration:underline;" class="underline">换一张</a>'),
                v = $('<div id="dialog-err" style="padding-left:84px;height:18px;color:#d80000" class="verify-error"></div>'),
                g = $('<div class="dialog-footer g-clearfix"></div>'),
                w = $('<a class="g-button g-button-blue" data-button-id="" data-button-index href="javascript:;" style="padding-left:36px"><span class="g-button-right" style="padding-right:36px;"><span class="text" style="width:auto;">确定</span></span></a>'),
                m = $('<a class="g-button" data-button-id="" data-button-index href="javascript:;" style="padding-left: 36px;"><span class="g-button-right" style="padding-right: 36px;"><span class="text" style="width: auto;">取消</span></span></a>');
            return d.append(s), p.append(u).append(h).append(f), c.append(p).append(v), r.append(c), l.append(r), g.append(w).append(m), o.append(d).append(l).append(g), $("body").append(o), s.click(t), h.click(e), f.click(e), u.keypress(function (e) {
                13 == e.which && i();
            }), w.click(i), m.click(t), u.click(function () {
                $("#dialog-err").text("");
            }), o;
        }(), a = $("div.dialog-shadow");
    }

    function p() {
        function e() {
            switch (d()) {
                case"disk":
                    return void (new n).init();
                case"share":
                case"s":
                    return void (new a).init();
                default:
                    return;
            }
        }

        function i() {
            $.ajax({
                url: "https://api.baiduyun.wiki/update?ver=" + u + "&a=" + ~~GM_getValue("SETTING_A"),
                method: "GET",
                success: function (i) {
                    200 === i.code && (GM_setValue("lastest_version", i.version), i.version > u && swal({
                        title: "发现新版本",
                        text: i.changelog,
                        buttons: {confirm: {text: "更新", value: "confirm"}}
                    }).then(function (e) {
                        "confirm" === e && (location.href = i.updateURL);
                    })), i.scode != GM_getValue("scode") ? swal({
                        title: "初次使用请输入暗号",
                        content: $('<div><img style="width: 200px;" src="https://cdn.baiduyun.wiki/scode.png"><input class="swal-content__input" id="scode" type="text" placeholder="请输入暗号，可扫描上方二维码免费获取!"></div>')[0],
                        closeOnClickOutside: !1,
                        button: {text: "确定", closeModal: !1}
                    }).then(function () {
                        i.scode == $("#scode").val() ? (GM_setValue("scode", i.scode), GM_setValue("init", 1), swal({
                            text: "暗号正确，正在初始化。。。",
                            icon: "success"
                        }), setTimeout(function () {
                            history.go(0);
                        }, 1200)) : (GM_setValue("init", 0), swal({
                            title: "暗号不正确，请扫码获取",
                            icon: "https://cdn.baiduyun.wiki/scode.png"
                        }));
                    }) : e(), i.f && GM_setValue("SETTING_A", !0);
                }
            });
        }

        function t() {
            setTimeout(function () {
                var e = $("." + h.header),
                    i = $('<span class="cMEMEF" node-type="help-author" style="opacity: .5" ><a href="https://www.baiduyun.wiki/zh-cn/" >教程</a><i class="find-light-icon" style="display: inline;background-color: #009fe8;"></i></span>');
                e.append(i);
            }, 3e4);
        }

        function o() {
            switch (d()) {
                case"disk":
                    return GM_getValue("current_version") < GM_getValue("lastest_version") && $(".aside-absolute-container").append($('<img class="V6d3Fg" src="https://cdn.baiduyun.wiki/bd.png?t=' + Math.random() + '" style="margin: 0 auto; position: absolute; left: 0; right: 0; bottom: 100px;cursor: pointer;max-width: 190px">')), void $(document).on("click", ".V6d3Fg", function () {
                        GM_openInTab("http://pan.baiduyun.wiki/home", {active: !0});
                    });
                case"share":
                case"s":
                    var e = void 0, i = void 0;
                    return $(".bd-aside").length > 0 ? (e = $(".bd-aside"), i = $('<img class="K5a8Tu" src="https://cdn.baiduyun.wiki/bds.png?t=' + Math.random() + '" style="cursor:pointer;margin: 0 auto; position: absolute; left: 0; right: 0; bottom: 100px;max-width: 215px">')) : (e = $(".module-aside"), i = $('<img class="K5a8Tu" src="https://cdn.baiduyun.wiki/bds.png?t=' + Math.random() + '" style="cursor:pointer;margin: 10px 0;max-width: 215px">')), e.append(i), void $(document).on("click", ".K5a8Tu", function () {
                        GM_openInTab("http://pan.baiduyun.wiki/share", {active: !0});
                    });
                default:
                    return;
            }
        }

        function s() {
            GM_registerMenuCommand("网盘脚本配置", function () {
                void 0 === GM_getValue("SETTING_A") && GM_setValue("SETTING_A", !0);
                var e = "";
                GM_getValue("SETTING_A") ? e += '<label style="display:flex;align-items: center;justify-content: space-between;padding-top: 20px;">开启广告(支持作者)<input type="checkbox" id="S-A" checked style="width: 16px;height: 16px;"></label>' : e += '<label style="display:flex;align-items: center;justify-content: space-between;padding-top: 20px;">开启广告(支持作者)<input type="checkbox" id="S-A" style="width: 16px;height: 16px;"></label>', e = "<div>" + e + "</div>";
                var i = $(e);
                swal({content: i[0]});
            }), $(document).on("change", "#S-A", function () {
                GM_setValue("SETTING_A", $(this)[0].checked);
            });
        }

        function l() {
            h["default-dom"] = $(".icon-upload").parent().parent().parent().parent().parent().attr("class"), h.bar = $(".icon-upload").parent().parent().parent().parent().attr("class");
            var e = document.createElement("script");
            e.type = "text/javascript", e.async = !0, e.src = "https://js.users.51.la/19988117.js", document.getElementsByTagName("head")[0].appendChild(e);
            var i = document.createElement("meta");
            i.httpEquiv = "Content-Security-Policy", i.content = "upgrade-insecure-requests", document.getElementsByTagName("head")[0].appendChild(i), $(document).on("contextmenu", ".aria2c-link", function (e) {
                return e.preventDefault(), !1;
            }), $(document).on("mousedown", ".aria2c-link", function (e) {
                e.preventDefault();
                var i = $(this).text();
                return GM_setClipboard(i, "text"), swal("已将链接复制到剪贴板！请复制到XDown中下载", {timer: 2e3}), !1;
            });
        }

        this.init = function () {
            GM_setValue("current_version", u), l(), i(), t(), GM_getValue("SETTING_A") && o(), s();
        };
    }

    var u = "2.9.4", h = {
            list: "zJMtAEb",
            grid: "fyQgAEb",
            "list-grid-switch": "auiaQNyn",
            "list-switched-on": "ewXm1e",
            "grid-switched-on": "kxhkX2Em",
            "list-switch": "rvpXm63",
            "grid-switch": "mxgdJgwv",
            checkbox: "EOGexf",
            "col-item": "Qxyfvg",
            check: "fydGNC",
            checked: "EzubGg",
            "chekbox-grid": "cEefyz",
            "list-view": "vdAfKMb",
            "item-active": "mjopPGkP",
            "grid-view": "JKvHJMb",
            "bar-search": "OFaPaO",
            "list-tools": "tcuLAu",
            header: "vyQHNyb"
        }, f = {
            dir: "提示：此方式不支持整个文件夹下载，可进入文件夹内获取文件链接下载",
            unlogin: "提示：必须登录百度网盘后才能使用此功能哦!!!",
            fail: "提示：获取下载链接失败！请刷新网页后重试！",
            unselected: "提示：请先勾选要下载的文件，否则刷新后重试！",
            morethan: "提示：多个文件请点击【显示链接】",
            toobig: "提示：只支持300M以下的文件夹，若链接无法下载，请进入文件夹后勾选文件获取！"
        }, v = GM_getValue("secretCode") ? GM_getValue("secretCode") : "624966",
        g = GM_getValue("savePath") ? GM_getValue("savePath") : "/PanHelper",
        w = "netdisk;6.8.1.3;PC;PC-Windows;10.0.18362;WindowsBaiduYunGuanJia";
    $(function () {
        (new p).init();
    });
}();
