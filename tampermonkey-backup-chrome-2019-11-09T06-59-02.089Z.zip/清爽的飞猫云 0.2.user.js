// ==UserScript==
// @name         清爽的飞猫云 0.2
// @namespace    Aloxaf_i
// @version      0.2.0
// @description  去除飞猫云的时间限制
// @author       Aloxaf
// @match        https://www.feimaoyun.com/*
// @grant        GM_addStyle
// @grant        unsafeWindow
// @run-at       document-start
// ==/UserScript==

/* jshint esversion: 6 */

function delete_cookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

// 取消两次下载间的时间限制
delete_cookie('fmdck');
